from django import forms
from .models import *

class StudentsForm(forms.ModelForm):
    class Meta:
        model=Students
        fields="__all__"
