from django.shortcuts import render,redirect
from .models import Students
from .forms import StudentsForm

def welcome(request):
    return  render(request,"welcome.html")

def load_form (request):
    form=StudentsForm
    return render(request,"index.html",{'form':form})

def add(request):
    form = StudentsForm(request.POST)
    form.save()
    return  redirect("/show")

def show(request):
    students=Students.objects.all
    return render(request,'show.html',{'students':students})

def edit(request,id):
    students = Students.objects.get(id=id)
    return render(request,'edit.html',{'students':students})

def update(request,id):
    students =Students.objects.get(id=id)
    form = StudentsForm(request.POST, instance=students)
    form.save()
    return  redirect('/show')

def delete(request,id):
    students=Students.objects.get(id=id)
    students.delete()
    return redirect("/show")

def search(request):
    given_name=request.POST['name']
    students = Students.objects.filter(sname__icontains=given_name)
    return render(request, 'show.html', {'students': students})

