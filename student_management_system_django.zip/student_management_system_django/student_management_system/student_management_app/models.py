from django.db import models
class Students(models.Model):
    sid=models.IntegerField()
    sname=models.CharField(max_length=50)
    semail=models.EmailField()
    scontact=models.IntegerField()

